'''
Created on Oct 27, 2010
Logistic Regression Working Module
@author: Peter
'''
from numpy import *

def loadDataSet():
    dataMat = []; labelMat = []
    fr = open('testSet.txt')
    for line in fr.readlines():
        lineArr = line.strip().split()
        dataMat.append([1.0, float(lineArr[0]), float(lineArr[1])]) # 1 for the 0th feature as d
        labelMat.append(int(lineArr[2]))
    return dataMat,labelMat

def sigmoid(inX):
    return 1.0/(1+exp(-inX))

def gradAscent(dataMatIn, classLabels):
    dataMatrix = mat(dataMatIn)             #convert to NumPy matrix    # m * n
    labelMat = mat(classLabels).transpose() #convert to NumPy matrix    # like column vector, m*1
    m,n = shape(dataMatrix)
    alpha = 0.001
    maxCycles = 500
    weights = ones((n,1))
    for k in range(maxCycles):              #heavy on matrix operations
        h = sigmoid(dataMatrix*weights)     #matrix mult    # like column vector, m*1
        error = (labelMat - h)              #mat subtraction, just like vector.
        weights = weights + alpha * dataMatrix.transpose()* error #matrix mult  # transpose is for m,n -> n,m  ,error is m*1
        # w2 = w1 + alpha * x * (y-h) , so this is ascent(maxmium likelihood), as add the derivation, x*(y-h). If is descent(least cost) => w2 = w1 - alpha * x * (h-y)!
    return weights

def plotBestFit(weights):
    import matplotlib.pyplot as plt
    dataMat,labelMat=loadDataSet()
    dataArr = array(dataMat)
    n = shape(dataArr)[0]   # n is row 
    xcord1 = []; ycord1 = []
    xcord2 = []; ycord2 = []
    for i in range(n):
        if int(labelMat[i])== 1:
            xcord1.append(dataArr[i,1]); ycord1.append(dataArr[i,2])    # just use for here 2D, 1 is row, 2 is column (0 is d)
        else:
            xcord2.append(dataArr[i,1]); ycord2.append(dataArr[i,2])
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.scatter(xcord1, ycord1, s=30, c='red', marker='s')   # drow those points
    ax.scatter(xcord2, ycord2, s=30, c='green')
    x = arange(-3.0, 3.0, 0.1)      # set x is a range of values from -3 to 3, step is 0.1!
    y = (-weights[0]-weights[1]*x)/weights[2]   # z = d + w1*x + w2*y, set z=0 because z is sperated by 0(z is sigmoid's x)
    ax.plot(x, y)       # scatter to draw 3 point to a line?.
    plt.xlabel('X1'); plt.ylabel('X2');
    plt.show()

def stocGradAscent0(dataMatrix, classLabels):
    m,n = shape(dataMatrix)
    alpha = 0.01
    weights = ones(n)   #initialize to all ones # this is vector, not matrix!
    for i in range(m):  # use m times!
        h = sigmoid(sum(dataMatrix[i]*weights)) # mat[i] is vector, w is also vector, mutiple value is vector!
        error = classLabels[i] - h      # is 1 value, not matrix
        weights = weights + alpha * error * dataMatrix[i]
    return weights

def stocGradAscent1(dataMatrix, classLabels, numIter=150):
    m,n = shape(dataMatrix)
    weights = ones(n)   #initialize to all ones, this is vector, for it's stochastic! just one sample each, not like above all sample each.
    for j in range(numIter):
        dataIndex = range(m)
        for i in range(m):
            alpha = 4/(1.0+j+i)+0.0001    #apha decreases with iteration, does not go to 0 because of the constant.
                                        # when j<<max(i), alpha isn't strictly decreasing. to avoid, use such as simulated annealing!!
            randIndex = int(random.uniform(0,len(dataIndex)))   # len() count as dataIndex changing
            h = sigmoid(sum(dataMatrix[randIndex]*weights))
            error = classLabels[randIndex] - h
            weights = weights + alpha * error * dataMatrix[randIndex]
            del(dataIndex[randIndex])
    return weights

def classifyVector(inX, weights):
    prob = sigmoid(sum(inX*weights))
    if prob > 0.5: return 1.0
    else: return 0.0

def colicTest():
    frTrain = open('horseColicTraining.txt'); frTest = open('horseColicTest.txt')
    trainingSet = []; trainingLabels = []
    for line in frTrain.readlines():
        currLine = line.strip().split('\t')
        lineArr =[]
        for i in range(21):
            lineArr.append(float(currLine[i]))
        trainingSet.append(lineArr)
        trainingLabels.append(float(currLine[21]))
    trainWeights = stocGradAscent1(array(trainingSet), trainingLabels, 1000)
    errorCount = 0; numTestVec = 0.0
    for line in frTest.readlines():
        numTestVec += 1.0
        currLine = line.strip().split('\t')
        lineArr =[]
        for i in range(21):
            lineArr.append(float(currLine[i]))
        if int(classifyVector(array(lineArr), trainWeights))!= int(currLine[21]):
            errorCount += 1
    errorRate = (float(errorCount)/numTestVec)
    print "the error rate of this test is: %f" % errorRate
    return errorRate

def multiTest():
    numTests = 10; errorSum=0.0
    for k in range(numTests):
        errorSum += colicTest()
    print "after %d iterations the average error rate is: %f" % (numTests, errorSum/float(numTests))
        

'''

http://dataunion.org/17006.html
http://blog.csdn.net/dongtingzhizi/article/details/15962797

simulated annealing
http://www.cnblogs.com/heaad/archive/2010/12/20/1911614.html

GA , Genetic Algorithm
http://www.cnblogs.com/heaad/archive/2010/12/23/1914725.html

'''

