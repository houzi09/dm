
from numpy import *
import operator

import matplotlib
import matplotlib.pyplot as plt

def createDataSet():
	group = array([[1,2],[3,4],[0,1],[0,2]])
	labels = ['A','A','B','B']
	return group, labels


def classify0(inX, dataSet, labels, k):
    #dataSetSize = dataSet.shape[0]
    dataSetSize = len(dataSet)

    # tile: expand inX
    diffMat = tile(inX,(dataSetSize,1)) - dataSet
	sqDiffMat = diffMat**2
	# sum as row (because axis=1)
	sqDistances = sqDiffMat.sum(axis=1)
	distances = sqDistances**0.5

	# Returns the indices that would sort an array.
	# sort from smallest distance
	sortedDistIndicies = distances.argsort()

	classCount={}
    # head k nums
    for i in range(k):
		# pick according label
		voteIlabel = labels[sortedDistIndicies[i]]
		# key is class label, value is count number
		classCount[voteIlabel] = classCount.get(voteIlabel,0) + 1

	# itemgetter(1) : get nums from item(label, nums) as key
	# sortedClassCount = sorted(classCount.iteritems(), key=operator.itemgetter(1), reverse=True)
    sortedClassCount = sorted(classCount.iteritems(), key=lambda d: d[1], reverse=True)

	# most happens label name
	return sortedClassCount[0][0]


'''
example:

1----
b=a.iteritems()
for k,v in b:
	print k,v

2---
a = [1,2,3] 
>>> b=operator.itemgetter(1)      //定义函数b，获取对象的第2个域的值(即第二个元素)
>>> b(a) 
2 
>>> b=operator.itemgetter(1,0)  //定义函数b，获取对象的第2个和第1个
>>> b(a) 
(2, 1)


'''


def file2matrix(filename):
	fr = open(filename)
	content = fr.readlines()
	numberOfLines = len(content)
	# zeros : expand
    # 3 is feature nums
	returnMat = zeros((numberOfLines,3))
	classLabelVector = []
	fr.close

	index = 0
	for line in content:
		line = line.strip()
		listFromLine = line.split('\t')
		returnMat[index,:] = listFromLine[0:3]
		classLabelVector.append(int(listFromLine[-1]))
		index += 1
	return returnMat,classLabelVector




import matplotlib
import matplotlib.pyplot as plt
fig = plt.figure()
# 111 mean   figure has dimensions *numRows*,
#*numCols*, and where *plotNum* is the number of the subplot
# being created.  *plotNum* starts at 1 in the upper left
# corner and increases to the right.
ax = fig.add_subplot(111)
datingDataMat,datingLabels = file2matrix('datingTestSet.txt')
# [:,1] get all col index 1
ax.scatter(datingDataMat[:,1], datingDataMat[:,2])
plt.show()




def autoNorm(dataSet):
    # 0 is in horizontal axis, each col's max/min value
    minVals = dataSet.min(0)
    maxVals = dataSet.max(0)
    ranges = maxVals - minVals
    normDataSet = zeros(shape(dataSet))
    m = dataSet.shape[0]
    normDataSet = dataSet - tile(minVals, (m,1))
    normDataSet = normDataSet/tile(ranges, (m,1))
    return normDataSet, ranges, minVals


def datingClassTest():
    hoRatio = 0.10
    datingDataMat,datingLabels = file2matrix('datingTestSet.txt')
    normMat, ranges, minVals = autoNorm(datingDataMat)
    # all len
    m = normMat.shape[0]
    # 0.9 to train but KNN is no train here, they used for sample! so just use 0.1 to test
    numTestVecs = int(m*hoRatio)
    errorCount = 0.0

    # use head 0.1 part
    for i in range(numTestVecs):
        # numTestVecs:m is 0.9 part
        classifierResult = classify0(normMat[i,:],normMat[numTestVecs:m,:], datingLabels[numTestVecs:m],3)

        print "the classifier came back with: %d, the real answer is: %d" % (classifierResult, datingLabels[i])
        if (classifierResult != datingLabels[i]):
            errorCount += 1.0

    print "the total error rate is: %f" % (errorCount/float(numTestVecs))

