The code for the examples in Ch.1 is contained in the python module: kNN.py.
The examples assume that datingTestSet.txt is in the current working directory.  
Folders testDigits, and trainingDigits are assumed to be in this folder also.  